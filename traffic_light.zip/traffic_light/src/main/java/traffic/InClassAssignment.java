package traffic;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import static javafx.geometry.Pos.CENTER;

public class InClassAssignment extends Application {
    @Override
    public void start(Stage primaryStage) {
        StackPane panel = new StackPane();
        //rectangle
        Rectangle rectangle = new Rectangle(40,100);
        panel.getChildren().addAll(rectangle);
        panel.setAlignment(CENTER);
        rectangle.setFill(Color.LIGHTGRAY);

        //circles
        VBox circlePane = new VBox(10);
        circlePane.setAlignment(CENTER);
        //creating 3 circles
        Circle circle1 =  new Circle(30,30,5);
        Circle circle2 =  new Circle(20,20,5);
        Circle circle3 =  new Circle(10,10,5);
        circlePane.getChildren().addAll(circle1,circle2,circle3);
        circle1.setFill(Color.TRANSPARENT);
        circle2.setFill(Color.TRANSPARENT);
        circle3.setFill(Color.TRANSPARENT);
        panel.getChildren().addAll(circlePane);

        //radio buttons
        RadioButton rRed = new RadioButton("Red");
        RadioButton rYellow = new RadioButton("Yellow");
        RadioButton rGreen = new RadioButton("Green");

        //H box to add the radio buttons in
        HBox radioPane = new HBox(10);
        radioPane.getChildren().addAll(rRed, rGreen, rYellow);
        radioPane.setAlignment(Pos.BOTTOM_CENTER);
        panel.getChildren().addAll(radioPane);


        // creates toggle group for the radio buttons
        ToggleGroup group = new ToggleGroup();
        rRed.setToggleGroup(group);
        rYellow.setToggleGroup(group);
        rGreen.setToggleGroup(group);

        // if statements for the right buttons
        rRed.setOnAction(e ->
        {
            if (rRed.isSelected())
            {
                circle1.setFill(Color.RED);
                circle2.setFill(Color.TRANSPARENT);
                circle3.setFill(Color.TRANSPARENT);
            }
        });

        rYellow.setOnAction(e ->
        {
            if (rYellow.isSelected())
            {
                circle1.setFill(Color.TRANSPARENT);
                circle2.setFill(Color.YELLOW);
                circle3.setFill(Color.TRANSPARENT);
            }
        });

        rGreen.setOnAction(e ->
        {
            if (rGreen.isSelected())
            {
                circle1.setFill(Color.TRANSPARENT);
                circle2.setFill(Color.TRANSPARENT);
                circle3.setFill(Color.GREEN);
            }
        });


        Scene scene = new Scene(panel);
        primaryStage.setTitle("Traffic Light");
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void main(String[] args) {
        launch();
    }
}
